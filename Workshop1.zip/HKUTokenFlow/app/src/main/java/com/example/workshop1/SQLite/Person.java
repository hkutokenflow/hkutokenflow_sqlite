package com.example.workshop1.SQLite;

public class Person {
    private String name;
    private String sex;
    private String date;
    private String id;

    public Person(String name, String sex, String date, String id) {
        this.name = name;
        this.sex = sex;
        this.date = date;
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
}
