package com.example.workshop1.Student.EventCheckin;

import android.os.Bundle;
import com.journeyapps.barcodescanner.CaptureActivity;

public class CustomScannerActivity extends CaptureActivity {
    // 默认即可，控制竖屏
}
